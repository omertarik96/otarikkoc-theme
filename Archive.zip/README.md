# OTARIKKOC Modern Wordpress Theme

Redesigning the [educational website](http://otarikkoc.com) by using modern wordpress development technologies. 

*Speed* and *Easy Maintenance* are my main focus on this theme.  

# Used Technologies
* <a href="#">Wordpress </a>
* <a href="#">Saga Starter Theme </a>
* <a href="#">Bootstrap 4 </a>
* <a href="#">Laravel Blade </a>
* <a href="#">SCSS </a>
* <a href="#">Webpack </a>