



<footer class="footer">
  <div class="container">
    <nav>
      <ul>
        <li>
          <a href="{{get_home_url()}}">
            Anasayfa
          </a>
        </li>
        <li>
          <a href="{{ get_home_url() }}/hakkimizda">
            Hakkımızda
          </a>
        </li>
        <li>
          <a href="{{ get_home_url()}}/blog">
            Blog
          </a>
        </li>
        <li>
          <a href="{{ get_home_url()}}/legal ">
            Legal
          </a>
        </li>
      </ul>
    </nav>
    <div class="copyright">
      &copy; 2017, OTARIKKOC bir LORE markasıdır.
        <a href="http://linkedin.com/in/otarikkoc" target="_blank">Omer Tarik Koc</a> tarafından &#9829; ve ☕ ile geliştirildi.

    </div>
  </div>
</footer>
</div>
</div>


{{--<footer class="content-info">--}}
{{--<div class="container">--}}
{{--@php(dynamic_sidebar('sidebar-footer'))--}}
{{--</div>--}}
{{--</footer>--}}