



<footer class="footer">
  <div class="container">
    <nav>
      <ul>
        <li>
          <a href="#">
            Homepage
          </a>
        </li>
        <li>
          <a href="#">
            About Us
          </a>
        </li>
        <li>
          <a href="#">
            Blog
          </a>
        </li>
        <li>
          <a href="#">
            MIT License
          </a>
        </li>
      </ul>
    </nav>
    <div class="copyright">
      &copy; 2017

      , Designed and developed by
      <a href="http://linkedin.com/in/otarikkoc" target="_blank">Omer Tarik Koc</a>.

    </div>
  </div>
</footer>
</div>
</div>


{{--<footer class="content-info">--}}
{{--<div class="container">--}}
{{--@php(dynamic_sidebar('sidebar-footer'))--}}
{{--</div>--}}
{{--</footer>--}}