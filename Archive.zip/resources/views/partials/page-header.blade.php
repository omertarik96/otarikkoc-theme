<div class="wrapper">
  <div class="page-header-image bg-main-color" data-parallax="true">
    <div class="container container-promo">
      <h3>Get Free 5 Days Course </h3>
      <p>Some Details and Summary About the Exam. We will provide the best resources for you</p>
      <div class="form-group">
        <input class="cta-input form-control form-control-transparent" type="text" value="" placeholder="name@email.com"
               class="form-control">
        <button class="btn btn-success cta-button"> Submit</button>
      </div>
      </span>
    </div>
  </div>
</div>